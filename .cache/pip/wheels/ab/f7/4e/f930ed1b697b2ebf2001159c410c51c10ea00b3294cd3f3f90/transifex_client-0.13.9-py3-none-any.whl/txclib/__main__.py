# -*- coding: utf-8 -*-

from .cmdline import main

main()
