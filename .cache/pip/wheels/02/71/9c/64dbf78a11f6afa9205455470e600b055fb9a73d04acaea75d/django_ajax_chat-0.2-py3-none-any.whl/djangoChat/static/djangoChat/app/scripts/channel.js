define(['backbone'], function (Backbone) {
    var channel = _.extend({}, Backbone.Events);
    return channel;
});